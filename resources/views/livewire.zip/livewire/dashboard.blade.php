<div>
    

    {{-- CoreUI content here --}}
</div>